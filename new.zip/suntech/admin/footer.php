
    <h1 style="text-align:center;background-color:black;color:white;font-size:20px;padding:20px 0;">Admin Panel</h1>
