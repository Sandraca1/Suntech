<?php
$data = [
    "key"               => 'rzp_test_g9nsCrZ66aag7L',
    "amount"            => $_POST['amount'],
    "name"              => 'SunTech',
    "description"       => 'SunTech - Solars And Inverters',
    "image"             => "",
    "prefill"           => [
    "name"              => $_POST['cust_name'],
    "email"             => $_POST['email'],
    "contact"           => $_POST['contact'],
    ],
    "notes"             => [
    "address"           => $_POST['address'],
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
];
?>