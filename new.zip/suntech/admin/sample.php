<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/upload.css">
</head>
<body>
<?php if(isset($_POST['itemID'])) : ?>
<div>
<?php
include("config.php");
if(isset($_POST['itemID'])){
    $sql = "SELECT * FROM item WHERE itemID =".$_POST['itemID'];
    $result = $conn->query($sql);
}
else{
    if(isset($_POST["itemName"])){
    $query = "UPDATE `item` SET `itemName`='".$_POST['itemName']."',`itemDesc`='".$_POST['itemDesc']."',`image`='".$_POST['image']."',`category`='".$_POST['category']."',`availableSize`='".$_POST['availableSize']."',`quantity`='".$_POST['quantity']."',`price`='".$_POST['price']."',`discount`='".$_POST['discount']."',`rent`='".$_POST['rent']."'WHERE itemID =".$_POST['itemIDUP'];
    //$query = "UPDATE `item` SET `itemName`='".$_POST['itemName']."',`itemDesc`='".$_POST['itemDesc']."',`availableSize`='".$_POST['availableSize']."',`price`='".$_POST['price']."',`discount`='".$_POST['discount']."'";
    $result= mysqli_query($conn,$query);
    }
    $query = "SELECT * FROM item";
    $result= mysqli_query($conn,$query);
}
    while($rows=mysqli_fetch_assoc($result)){
?>
<form action="update.php" method="POST" style="font-family: Arial, sans-serif; background-color: #f2f2f2; padding: 20px;">
<h3 style='text-align:center;margin:15px 0;'>Update Product</h3>
<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Product Name:</span>
<input type="text" name="itemName" style="width:100%" value="<?php echo $rows['itemName']; ?>">
</label>

<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Product Description:</span>
<textarea name="itemDesc" style="width:100%"><?php echo $rows['itemDesc']; ?></textarea>
</label>
<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Item Category:</span>
<textarea name="category" style="width:100%"><?php echo $rows['category']; ?></textarea>
</label>

<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Price:</span>
<input type="number" name="price" style="width:100%"  value="<?php echo $rows['price']; ?>">
</label>

<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Discount:</span>
<input type="number" name="discount" style="width:100%"  value="<?php echo $rows['discount']; ?>">
</label>
<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Rent:</span>
<input type="number" name="rent" style="width:100%"  value="<?php echo $rows['rent']; ?>">
</label>

<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Size:</span>
<input type="text" name="availableSize" style="width:100%"  value="<?php echo $rows['availableSize']; ?>">
</label>
<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Quantity:</span>
<input type="number" name="quantity" style="width:100%" value="<?php echo $rows['quantity']; ?>">
</label>
<label style="display: block; margin-bottom: 10px;">
<span style="display: block;font-weight: bold;">Image:</span>
<input type="file" name="image" style="width:100%" value="<?php echo $rows['image']; ?>">  
</label>
<input type="hidden" name="itemIDUP" value="<?php echo $rows['itemID']; ?>">
<div style="width:100%;display:flex;justify-content:center;">
<button style="margin:0 auto;background-color:#0865ff;border:none;padding:5px 7px;border-radius:5px;color:white;cursor:pointer;" type="submit">Submit</button>
</div>
</form>
<?php
    }
?>
</div>
<?php endif; ?>
</body>
</html>