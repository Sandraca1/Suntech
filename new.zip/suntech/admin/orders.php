<?php
session_start();
if (!isset($_SESSION['aid'])) {
  header("Location: login.php");
  exit();
}
$i = 0;
?>
<?php include ("navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SunTech - Products</title>
  <link rel="stylesheet" href="../css/admin.scss">
  <style>
    #customers {
      font-family: Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }

    #customers td,
    #customers th {
      border: 1px solid #ddd;
      padding: 8px;
    }

    #customers tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    #customers tr:hover {
      background-color: #ddd;
    }

    #customers th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      background-color: #04AA6D;
      color: white;
    }


    #addp {
      background-color: #2ea44f;
      border-radius: 8px;
      border-style: none;
      box-sizing: border-box;
      color: #FFFFFF;
      cursor: pointer;
      display: inline-block;
      font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
      font-size: 14px;
      font-weight: 500;
      height: 40px;
      line-height: 20px;
      list-style: none;
      margin: 0;
      outline: none;
      padding: 10px 16px;
      position: relative;
      text-align: center;
      text-decoration: none;
      transition: color 100ms;
      vertical-align: baseline;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
    }

    #addp:hover,
    #addp:focus {
      background-color: transparent;
      border: solid #2ea44f 1px;
      color: black;
    }


    #updateb {
      background-color: #2962FF;
      border-radius: 8px;
      border-style: none;
      box-sizing: border-box;
      color: #FFFFFF;
      cursor: pointer;
      display: inline-block;
      font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
      font-size: 14px;
      font-weight: 500;
      height: 40px;
      line-height: 20px;
      list-style: none;
      margin: 0;
      outline: none;
      padding: 10px 16px;
      position: relative;
      text-align: center;
      text-decoration: none;
      transition: color 100ms;
      vertical-align: baseline;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
    }

    #updateb:hover,
    #updateb:focus {
      background-color: transparent;
      border: solid #2962FF 1px;
      color: black;
    }


    #deleteb {
      background-color: #EA4C89;
      border-radius: 8px;
      border-style: none;
      box-sizing: border-box;
      color: #FFFFFF;
      cursor: pointer;
      display: inline-block;
      font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
      font-size: 14px;
      font-weight: 500;
      height: 40px;
      line-height: 20px;
      list-style: none;
      margin: 0;
      outline: none;
      padding: 10px 16px;
      position: relative;
      text-align: center;
      text-decoration: none;
      transition: color 100ms;
      vertical-align: baseline;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
    }

    #deleteb:hover,
    #deleteb:focus {
      background-color: transparent;
      border: solid #EA4C89 1px;
      color: black;
    }
  </style>
</head>

<body>
  <h1 style="text-align:center;margin:7% 0;font-size:3rem;">Orders</h1>
  <div style="padding:5% 20px;">
    <table id="customers">
      <tr>
        <th>Slno</th>
        <th>Order ID</th>
        <th>Customer ID</th>
        <th>Customer Name</th>
        <th>Address</th>
        <th>Amount</th>
        <th>Product</th>
        <th>Qty</th>
        <th>Order Status</th>
        <th>Update Status</th>
      </tr>
      <?php
      include 'db_connect.php';
      $qry = $conn->query("SELECT * FROM orders");
      while ($row = $qry->fetch_assoc()):
        ?>
        <tr>
          <td>
            <?php echo $i = $i + 1 ?>
          </td>
          <td>
            <?php echo $row['order_id'] ?>
          </td>
          <td>
            <?php echo $row['cust_id'] ?>
          </td>
          <td>
            <?php echo $row['cust_name'] ?>
          </td>
          <td>
            <?php echo substr($row['address'], 0, 50) ?>
          </td>
          <td>
            <?php echo $row['amount'] ?>
          </td>
          <td>
            <?php echo $row['p_name'] ?>
          </td>
          <td>
            <?php echo $row['qty'] ?>
          </td>
          <td><span
              style="padding:4% 8%;color:white;background-color:<?php if ($row['order_status'] == 'pending') {
                echo '#EA4C89';
              } elseif ($row['order_status'] == 'on the way') {
                echo '#2962FF';
              } else {
                echo '#2ea44f';
              } ?>;border-radius:4px;">
              <?php echo $row['order_status'] ?>
            </span></td>
          <td>
            <form action="updateorder.php" method="POST">
              <select style='border:none;padding:7%;cursor:pointer;' name='status'>
                <option style='border:none;padding:7%;' value="pending">pending</option>
                <option style='border:none;padding:7%;' value="on the way">on the way</option>
                <option style='border:none;padding:7%;' value="delivered">delivered</option>
              </select>
              <input type="hidden" name="order_id" value='<?php echo $row['order_id'] ?>'>
              <input
                style='border:none;padding:5%;margin:5px;border-radius:2px 4px;color:white;background-color:#2962FF;cursor:pointer;'
                type="submit" value="update">
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
  <?php include ("footer.php"); ?>
</body>

</html>