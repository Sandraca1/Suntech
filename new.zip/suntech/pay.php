<?php
session_start();
require ('./config.php');
require ('./razorpay-php/Razorpay.php');

use Razorpay\Api\Api;

$api = new Api('rzp_test_VxXBZ37slfyArP', 'CcMG1o05q8Xclw0WRQfU2lJW');
$orderData = [
    'receipt' => 3456,
    'amount' => $_POST['amount'] * 100,
    'currency' => 'INR',
    'payment_capture' => 1
];
$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];
$_SESSION['razorpay_order_id'] = $razorpayOrderId;
$displayAmount = $amount = $orderData['amount'];
?>