<?php
session_start();
include ('./admin/db_connect.php');

//get the payment details from payment page
if (isset($_POST['payment_id']) && isset($_POST['amount']) && isset($_POST['name']) && isset($_POST['address']) && isset($_POST['cust_id'])) {
    $paymentId = $_POST['payment_id'];
    $cust_id = $_POST['cust_id'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    echo "<script>alert('product_id : $product_id, p_name : $p_name, p_price : $p_price, qty : $qty, img_path : $img_path');</script>";
    //insert data into database'
    $uid = $_SESSION["id"];
    $sql = "SELECT * FROM cart WHERE user_id='$uid'";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $amount = $row['total'];
        $product_id = $row['product_id'];
        $p_name = $row['p_name'];
        $p_price = $row['p_price'];
        $qty = $row['qty'];
        $img_path = $row['img_path'];
        $sql1 = "INSERT INTO `orders` (`order_id`, `cust_id`, `cust_name`, `address`, `amount`, `payment_id`, `product_id`, `p_name`, `p_price`, `qty`, `img_path`, `order_status`, `order_date`) VALUES (CONCAT('ORD-', FLOOR(RAND() * 10000)),'$cust_id','$name','$address','$amount','$paymentId','$product_id','$p_name','$p_price','$qty','$img_path','pending',CURDATE())";
        $result1 = $conn->query($sql1);
    }
    $dsql = "DELETE FROM `cart` WHERE user_id='$cust_id'";
    $result = $conn->query($dsql);
} else {
    echo "<script>alert('Values were not visible');</script>";
}
?>