-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2023 at 01:51 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abidf`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cid` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_id` int(30) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `p_price` float NOT NULL,
  `qty` int(30) NOT NULL,
  `img_path` varchar(300) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cid`, `user_id`, `product_id`, `p_name`, `p_price`, `qty`, `img_path`, `total`) VALUES
(23, 3, 5, 'Havells Solar Panel', 4352, 1, 'Havells_Solar_Panel.jpeg', 4352);

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `name`) VALUES
(1, 'Beverages'),
(3, 'Best Sellers'),
(4, 'Meals'),
(5, 'Snacks'),
(6, 'Dessert');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `mobile` text NOT NULL,
  `email` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `address`, `mobile`, `email`, `status`) VALUES
(1, 'James Smith', 'adasdasd asdadasd', '4756463215', 'jsmith@sample.com', 1),
(2, 'James Smith', 'adasdasd asdadasd', '4756463215', 'jsmith@sample.com', 1),
(3, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1),
(4, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1),
(5, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1),
(6, 'Abidul cse.aishaon@gmail.com', 'Durgapur,kathgara,zirabo,Ashulia', '0172238545', 'cse.aishaon@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `product_id`, `qty`) VALUES
(1, 1, 3, 1),
(2, 1, 5, 1),
(3, 1, 3, 1),
(4, 1, 6, 3),
(5, 2, 1, 2),
(6, 3, 6, 2),
(7, 3, 7, 1),
(8, 4, 1, 1),
(9, 4, 4, 1),
(10, 5, 6, 2),
(11, 5, 1, 2),
(12, 6, 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `img_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0= unavailable, 2 Available',
  `qty` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `category_id`, `name`, `description`, `price`, `img_path`, `status`, `qty`) VALUES
(1, 3, 'Photovoltaic Monocrystalline Silicone Solar Panel', 'A monocrystalline PV panel is a premium energy-producing panel consisting of smaller monocrystalline solar cells (60 to 72 cells).\n\nTheir superior aesthetics and efficiency make them the preferred choice for intelligent solar thinkers investing in the long term.\n\n', 3000, 'Photovoltaic_Monocrystalline_Silicone_Solar_Panel.jpeg', 1, '3000'),
(3, 3, 'High Efficiency Monocrystalline Silicone Solar Panel', 'The monocrystalline silicone solar panels are known for their excellent performance and durability. They are highly efficient in converting sunlight into electricity, thanks to the uniformity and purity of the crystal structure.', 2500, 'High_Efficiency_Monocrystalline_Silicone_Solar_Panel.jpeg', 1, '1997'),
(4, 3, 'High Efficiency Solar Photovoltaic Panel', 'The high efficiency of these solar panels is due to their advanced technology, which uses high-quality materials and advanced manufacturing processes. ', 7640, 'High_Efficiency_Solar_Photovoltaic_Panel.jpeg', 1, '1493'),
(5, 3, 'Havells Solar Panel', 'The Havells solar panels are available in different sizes and power ratings to suit various applications, from residential to commercial solar power systems.', 4352, 'Havells_Solar_Panel.jpeg', 1, '196'),
(6, 3, 'Vguard Solar Water Heater', 'The Vguard solar water heaters come with a high-efficiency evacuated tube collector, which absorbs heat from the sun and transfers it to the water. ', 4322, 'Vguard_Solar_Water_Heater.jpeg', 1, '497'),
(7, 3, 'V-Guard Win-Hot Series 200 LPD Solar Water Heater', 'The V-Guard Win-Hot Series 200 LPD Solar Water Heater comes with a high-efficiency evacuated tube collector that absorbs heat from the sun and transfers it to the water. ', 5422, 'V-Guard_Win-Hot_Series_200_LPD_Solar_Water_Heater.jpeg', 1, '399'),
(8, 3, 'Solar Geyser', 'A solar geyser is a type of water heating system that uses the power of the sun to heat water.', 1770, 'Solar_Geyser.jpeg', 1, '4998'),
(9, 3, 'Exide 150 Ah Inva Red 500 Plus Inerter Battery', 'The Exide 150 Ah Inva Red 500 Plus Inverter Battery has a capacity of 150 Ah, making it an ideal solution for homes or businesses with high power requirements.', 4524, 'Exide_150_Ah_Inva_Red_500_Plus_Inerter_Battery.jpeg', 1, '2997');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'SunTecH', 'admin@admin.com', '+639079373999', '1668911820_background.jpg', 'Welcome to our inverter and solar website! We are a team of passionate professionals dedicated to providing sustainable energy solutions for homes and businesses alike.\n\nOur journey began with a simple idea: to create a cleaner, more sustainable world by harnessing the power of the sun. As we delved deeper into the world of solar energy, we realized that in order to truly make a difference, we needed to offer a complete solution that not only generated energy, but also stored and managed it efficiently. This led us to the world of inverters and battery storage systems, where we have since become experts in the field.\n\nAt our core, we are committed to making solar energy accessible to everyone. We believe that everyone should have the opportunity to benefit from the cost savings and environmental benefits of renewable energy, regardless of their location or budget. That\'s why we offer a wide range of products and services, from simple off-grid systems for remote locations, to complex grid-tied systems for commercial applications.\n\nOur team is made up of experienced professionals who are passionate about what they do. We have engineers, designers, installers, and customer service representatives who all work together to ensure that our clients receive the best possible service and support. We are committed to staying up-to-date with the latest technology and trends in the industry, so that we can continue to offer the most advanced and effective solutions to our clients.\n\nWe understand that investing in a solar energy system can be a significant decision, which is why we take the time to understand our clients\' unique needs and goals. We work closely with our clients to design and install customized solutions that meet their specific requirements, while also providing ongoing support and maintenance to ensure that their system operates at peak efficiency.\n\nThank you for considering us as your partner in the journey towards a sustainable future. We look forward to working with you to create a brighter, cleaner world for generations to come.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile`, `address`, `password`) VALUES
(1, 'Richu', 'Sony', 'sonyrichu4@gmail.com', '9947619644', 'adfadfa adfada adfadf adfadf adfadf afd', 'richusony123'),
(2, 'Ankith', 'kasaragod', 'ankith@gmail.com', '1234567891', 'zdfgsrgsgs sfgsgdgae rqwer', '1234567891'),
(3, 'Simal', 'Baby', 'simal@gmail.com', '8086219644', 'adfadfadfadfa', 'simal12345');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address`) VALUES
(1, 'James', 'Smith', 'jsmith@sample.com', '1254737c076cf867dc53d60a0364f38e', '4756463215', 'adasdasd asdadasd'),
(2, 'FreeWebsite', 'Code', 'admin@freewebsitecode.com', '827ccb0eea8a706c4c34a16891f84e7b', '+639079373', '06106 Capitol Site, Brgy. Washington'),
(3, 'Abidul', 'cse.aishaon@gmail.com', 'cse.aishaon@gmail.com', 'dfccf0c79f1b94cd96b7ea0dd360ee06', '0172238545', 'Durgapur,kathgara,zirabo,Ashulia');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
