 <!-- Masthead-->
        <header style='background-color:black;height:15rem;'>
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                         <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                    </div>
                </div>
            </header>
            
    <section class="page-section">
        <div class="container">
    <!-- <?php echo html_entity_decode($_SESSION['setting_about_content']) ?>         -->
    <p><span style="font-size:20px;font-weight:bold;">Welcome to our SunTecH</span> inverter and solar website! We are a team of passionate professionals dedicated to providing sustainable energy solutions for homes and businesses alike.

Our journey began with a simple idea: to create a cleaner, more sustainable world by harnessing the power of the sun. As we delved deeper into the world of solar energy, we realized that in order to truly make a difference, we needed to offer a complete solution that not only generated energy, but also stored and managed it efficiently. This led us to the world of inverters and battery storage systems, where we have since become experts in the field.

At our core, we are committed to making solar energy accessible to everyone. We believe that everyone should have the opportunity to benefit from the cost savings and environmental benefits of renewable energy, regardless of their location or budget. That's why we offer a wide range of products and services, from simple off-grid systems for remote locations, to complex grid-tied systems for commercial applications.

Our team is made up of experienced professionals who are passionate about what they do. We have engineers, designers, installers, and customer service representatives who all work together to ensure that our clients receive the best possible service and support. We are committed to staying up-to-date with the latest technology and trends in the industry, so that we can continue to offer the most advanced and effective solutions to our clients.

We understand that investing in a solar energy system can be a significant decision, which is why we take the time to understand our clients' unique needs and goals. We work closely with our clients to design and install customized solutions that meet their specific requirements, while also providing ongoing support and maintenance to ensure that their system operates at peak efficiency.

Thank you for considering us as your partner in the journey towards a sustainable future. We look forward to working with you to create a brighter, cleaner world for generations to come.</p>
            
        </div>
        </section>