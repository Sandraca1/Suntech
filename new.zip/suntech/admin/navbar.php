<?php 
if (!isset($_SESSION['name'])) {
	header("Location: login.php");
	exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/70218ce737.js" crossorigin="anonymous"></script>
	<title>SunTech</title>
</head>
<style>
	*{
		margin:0;
		padding:0;
		box-sizing:border-box;
	}
nav{
	background-color:#2962FF;
	padding: 10px 15px;
	width: 100%;
	display: flex;
	color:white;
	justify-content:space-between;
	align-items:center;
}

#side-bar{
transition:0.9s linear;
background-color:blue; //#FFFFFF;
width:15%;
padding:10px 2%;
position: absolute;
top: 25%;
border-radius:5px;
transform: translateX(-500px);
}

#side-bar a{
	text-decoration:none;

}

.hide{
	transform: translateX(-500px);
}

</style>
<body style="background-color:#EEF5F9;">
<nav>
		<div style="display:flex;justify-content:space-between;align-items:center;">
			<div style="margin-right:15px;cursor:pointer;" onclick="handleOpen()">
			<i id='menu' class="fa-solid fa-bars"></i>
			</div>
			<a href="index.php" style="text-decoration:none;color:white;">
			<h1 style="font-size:2rem;">
				SunTech
			</h1></a>
		</div>
		<div>
			<a href="logout.php" style="text-decoration:none;color:white;">
			<h1 style="cursor:pointer;">
				<?php echo $_SESSION['name'] ?> <i style="font-size:18px;" class="fa-solid fa-power-off"></i>
			</h1>
			</a>
		</div>
</nav>
<div id="side-bar">
	<h1 style="text-align:right;padding:0 3px 0 0;"><i style="cursor:pointer;" onclick="handleClose()" class="fa-solid fa-xmark"></i></h1>	
	<a href="index.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-house"></i>
		<h2>Dashboard</h2>
	</div></a>
	<a href="product.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-cart-shopping"></i>
		<h2>Products</h2>
	</div></a>

	<a href="orders.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-truck-fast"></i>
		<h2>Orders</h2>
	</div></a>

	<a href="users.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-users"></i>
		<h2>Users</h2>
	</div></a>

	<a href="report.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-file"></i>
		<h2>Reports</h2>
	</div></a>

	<a href="pie.php" style="text-decoration:none;color:white;"><div style="display:flex;justify-content:space-evently;align-items:center;cursor:pointer;margin:10px 0;">
		<i style="margin-right:5px;" class="fa-solid fa-chart-pie"></i>
		<h2>Report Chart</h2>
	</div></a>
	
</div>

<script>
	let sidebar=document.getElementById("side-bar");
	let menu=document.getElementById("menu");
	function handleOpen(){

sidebar.style.transform="translateX(0)";
menu.style.display="none";

	}
		function handleClose(){
		sidebar=document.getElementById("side-bar");
	sidebar.style.transform="translateX(-500px)";
	menu.style.display="block";
		}
</script>
</body>
</html>