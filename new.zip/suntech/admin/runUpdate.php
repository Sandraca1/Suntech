<?php
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $pnam=$_POST['pname'];
    $desc=$_POST['desc'];
    $price=$_POST['price'];
    $img_path=$_POST['img_path'];
    $qty=$_POST['qty'];
    $sqlone = "UPDATE product_list SET `id`='$id',`name`='$pname',`description`='$desc',`price`='$price',`img_path`='$img_path',`qty`='$qty' WHERE `id`=$updateid";
    $result = $conn->query($sqlone);
    if($result){
        alert("Successfull!");
    }else{
        alert("Hello");
    }
    }else{
        echo "Hello";
    }
?>