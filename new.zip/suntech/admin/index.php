<?php
session_start();
if (!isset($_SESSION['aid'])) {
     header("Location: login.php");
     exit();
}
include('./navbar.php'); 
include('./db_connect.php');
?>

<!DOCTYPE html>
<html>

<head>
     <title>Admin Dashboard</title>
     <link rel="stylesheet" href="style/admin-style.css">
     <script src="https://kit.fontawesome.com/70218ce737.js" crossorigin="anonymous"></script>
</head>

<body>
  <div class="dash-div">
    <div class="admin-head">
      <h1 style="padding:3% 2%;background-color:#F9FAFB;"> 
        Dashboard
      </h1>
    </div>

    <div style="padding:4% 2%;display:flex;">
    
      <div style="background-color:#F9FAFB;display:flex;justify-content:space-between;align-items:center;width:22%;padding:2% 1%;margin:0 auto;cursor:pointer;">
        <div style="text-align:left">
        <a href="users.php" style="text-decoration:none;background:none;width:fit-content;">
          <h2 style="color:#6B7280">Users</h2></a>
          <?php
                        $sqlone = "SELECT COUNT(id) as total_sum FROM users";
                        $sum = $conn->query($sqlone);
                        if ($sum->num_rows > 0) {
                          $row = $sum->fetch_assoc();
                        ?>
            <h3><?php echo $total_sum = $row['total_sum']; } ?></h3>
        </div>
        <div>
          <i style="color:#10B981;font-size:1.7rem;" class="fa-solid fa-users"></i>
        </div>
      </div>
      

      <div style="background-color:#F9FAFB;display:flex;justify-content:space-between;align-items:center;width:22%;padding:2% 1%;margin:0 auto;cursor:pointer;">
        <div style="text-align:left">
        <a href="product.php" style="text-decoration:none;background:none;width:fit-content;">
          <h2 style="color:#6B7280">Products</h2>
          <?php
                        $sqlone = "SELECT COUNT(id) as total_sum FROM product_list";
                        $sum = $conn->query($sqlone);
                        if ($sum->num_rows > 0) {
                          $row = $sum->fetch_assoc();
                        ?>
            <h3><?php echo $total_sum = $row['total_sum']; } ?></h3>
        </div>
        <div>
          <i style="color:#10B981;font-size:1.7rem;" class="fa-solid fa-cart-shopping"></i>
        </div>
      </div>
      
        
      </div>
      <div style="background-color:#F9FAFB;display:flex;justify-content:space-between;align-items:center;width:22%;padding:2% 1%;margin:0 auto;cursor:pointer;">
        <div style="text-align:left">
        <a href="orders.php" style="text-decoration:none;background:none;width:fit-content;">
          <h2 style="color:#6B7280">Orders</h2></a>
          <?php
                        $sqlone = "SELECT COUNT(order_id) as total_sum FROM orders";
                        $sum = $conn->query($sqlone);
                        if ($sum->num_rows > 0) {
                          $row = $sum->fetch_assoc();
                        ?>
            <h3><?php echo $total_sum = $row['total_sum']; } ?></h3>
        </div>

        
        <div>
          <i style="color:#10B981;font-size:1.7rem;" class="fa-solid fa-truck-fast"></i>
        </div>
      </div>
    </div>
  </div>       
</body>
</html>