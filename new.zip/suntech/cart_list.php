<!-- <?php
session_start();
if (!isset($_SESSION['id'])) {
     header("Location: login.php");
     exit();
}
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Your Cart</title>
     <!-- <link rel="stylesheet" href="./css/styles.css"> -->
     <!-- <link href="css/main.css" rel="stylesheet" /> -->
     <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/891/891462.png" type="image/x-icon">
</head>
<body>
	<div style='width:100%;'>
<div id="div-head"><h1 style='text-align:center;font-weight:bold;'>Your Cart</h1></div>
     <?php
     $uid = $_SESSION['id'];
     $name = $_SESSION['first_name'];
     $servername = "localhost";
     $username = "root";
     $password = "";
     $dbname = "abidf";
     $conn = new mysqli($servername, $username, $password, $dbname);
     if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
     }
     $sql = "SELECT * FROM cart WHERE user_id='$uid'";
     $sqlone = "SELECT SUM(total) as total_sum FROM cart WHERE user_id='$uid'";
     $result = $conn->query($sql);
     $sum = $conn->query($sqlone);
     if ($result) {
          if ($result->num_rows > 0) {	
               while ($row = $result->fetch_assoc()):
                    $image_path = "./assets/img/".$row['img_path'];
                    echo "
					<div style='width:100%;'>
						<div style='border:2px solid black;margin:15px auto;1px solid #dee2e6;width:80%; height:60%;background-color:#a694e370;'>
                            <div style='display:flex;justify-content:between;'>
								<img width='30%' src='" . $image_path . "'/>
								<div style='margin:auto auto;'>
                                    <h4 class='product-name'>" . $row['p_name'] . "</h4>
                                    <h4 class='price'> ₹" . $row['total'] . "</h4>
                                    <h4 class='qty'> Qty: " . $row['qty'] . "</h4>
                                    <form method='POST' action='deleteItem.php'>
                                        <input type='hidden' name='del_pid' value='" . $row["product_id"] . "'>
                                        <input type='hidden' name='item_qty' value='" . $row["qty"] . "'>
                                        <button type='submit' style='margin-top:10px;padding:6px 8px;border-radius:5px;background-color:#321eff;color:white;border:none;' class='add-to-cart-btn'>Remove</button>
                                    </form>
								</div>
							</div>
                        </div>
					</div>";
               endwhile;
          } else {
               echo "<div style='width:100%' class='empty-cart'>
			   						<div style='width:100%;margin:0 auto;'>
                                     <img style='display:flex;justify-content:center;margin:0 auto;width:20%;' src='https://cdn-icons-png.flaticon.com/512/1376/1376786.png' alt=''/>
                                     <h1 style='text-align:center'>" . $name . ", your cart is empty!</h1>
									 </div>
                               </div>";
          }
     } else {
          echo "Error in fetching cart items";
     }
     $conn->close();
     if ($sum && $sum->num_rows > 0) {
		$row = $sum->fetch_assoc();
		$total_sum = $row["total_sum"];
   }
   if (isset($total_sum) && $total_sum > 0) {
		echo "</div>
		<div style='margin: 10rem; 0;' class='place-order-div'>
		<div>
		<h1><span>₹</span>" . $total_sum .  " </h1>
		</div>
		<form method='POST' action='./checkout.php'>
			   <button type='submit' class='add-to-cart-btn' style='margin-top:10px;padding:6px 8px;border-radius:5px;background-color:#2ea44f;color:white;border:none;'>Place Order</button>
		</form>
		</div>";
   } else {
		echo "<div></div>";
   }
		?>
     </div>
	</div>
	</div>
</body>

</html>
	
