<?php
session_start();
if (!isset($_SESSION['id'])) {
     header("Location: login.php");
     exit();
}

if (isset($_POST['pid'])) {
     $pid = $_POST['pid'];
     echo($pid);
     $uid = $_SESSION['id'];
     $servername = "localhost";
     $username = "root";
     $password = "";
     $dbname = "abidf";

     try {
          $conn = new mysqli($servername, $username, $password, $dbname);
          if ($conn->connect_error) {
               throw new Exception("Connection failed: " . $conn->connect_error);
          }

          // Check if item already exists in cart
          $sql = "SELECT * FROM cart WHERE product_id = '$pid'";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
               // Update quantity of existing item in cart
               $row = $result->fetch_assoc();
               $cart_id = $row['cid'];
               $price = $row['p_price'];
               $quantity = $row['qty'] + 1;
               $sql = "UPDATE cart SET qty = '$quantity', total=total+'$price' WHERE user_id = '$uid' AND product_id= '$pid'";
               $updateQty = "UPDATE product_list  SET qty = qty-'$quantity' WHERE id = '$pid'";
               if ($conn->query($sql) === TRUE) {
                    $conn->query($updateQty);
                    echo "<script>alert('Item added to cart.');</script>";
                    echo "<script>window.location.href='index.php'</script>";
                    
               } else {
                    throw new Exception("Error updating cart: " . $conn->error);
               }
          } else {
               // Add new item to cart
               $sql = "SELECT * FROM product_list WHERE id = '$pid'";
               $result = $conn->query($sql);
               if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $product_id = $row['id'];
                    $product_name = $row['name'];
                    $quantity = $_POST['qty'];
                    $price = $row['price'];
                    $total = $row['price'] * $quantity;
                    $image = $row['img_path'];
                    echo $image;
                    if ($quantity > $row['qty']) {
                         throw new Exception("Quantity is high!");
                    } else {
                         $sql = "INSERT INTO `cart`(`user_id`, `product_id`, `p_name`, `p_price`, `qty`, `img_path`, `total`) VALUES ('$uid','$product_id','$product_name','$price','$quantity','$image','$total')";
                         $updateQty = "UPDATE product_list  SET qty = qty-'$quantity' WHERE id = '$product_id'";
                         if (mysqli_query($conn, $sql) === TRUE) {
                              $conn->query($updateQty);
                              echo "<script>alert('item added to cart.');</script>";
                              echo "<script>window.location.href='index.php'</script>";
                         } else {
                              throw new Exception("Error adding to cart: " . $conn->error);
                         }
                    }
               } else {
                    throw new Exception("Product not found!");
               }
          }

          $conn->close();
     } catch (Exception $e) {
          echo $e->getMessage();
     }
}
