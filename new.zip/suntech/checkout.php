<?php
session_start();
$uid = $_SESSION['id'];
$total_sum = 0;
?>

<head>
  <link rel="stylesheet" href="../suntech/credit-card-checkout/src/style.css">
</head>
<div class='container'>
  <div class='window'>
    <div class='order-info'>
      <div class='order-info-content'>
        <h2>Order Summary</h2>
        <?php include ('./admin/db_connect.php');
        $sql = "SELECT * FROM cart WHERE user_id='$uid'";
        $result = $conn->query($sql);
        if ($result) {
          if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()):
              ?>
              <div class='line'></div>
              <table class='order-table'>
                <tbody>
                  <tr>
                    <td><img src='./assets/img/<?php echo $row['img_path'] ?>' class='full-width'></img>
                    </td>
                    <td>
                      <br> <span class='thin'>
                        <?php echo $row['p_name'] ?>
                      </span>
                      <br> <span class='thin small'>
                        <?php echo $row['p_name'] ?><br><br>
                      </span>
                      <br> <span>Qty :
                        <?php echo $row['qty'] ?>
                      </span>
                    </td>

                  </tr>
                  <tr>
                    <td>
                      <div class='price'><span>₹</span>
                        <?php echo $row['p_price'] ?>
                      </div>
                    </td>
                  </tr>
                </tbody>

              </table>
            <?php endwhile;
          }
        }
        ?>
        <div class='line'></div>
        <div class='total'>
          <?php
          $sqlone = "SELECT SUM(total) as total_sum FROM cart WHERE user_id='$uid'";
          $sum = $conn->query($sqlone);
          if ($sum && $sum->num_rows > 0) {
            $row = $sum->fetch_assoc();
            $total_sum = $row["total_sum"];
          }
          if (isset($total_sum) && $total_sum > 0) { ?>
            <span style='float:left;'>
              <div class='thin dense'>Delivery</div>
              TOTAL
            </span>
            <span style='float:right; text-align:right;'>
              <div class='thin dense'>Rs. 4.95</div>
              <span>₹</span>
              <?php echo $total_sum;
          } ?>.00
          </span>
        </div>
      </div>
    </div>
    <div class='credit-info'>
      <div class='credit-info-content'>
        <img src='https://cdni.iconscout.com/illustration/premium/thumb/online-payment-with-mobile-2645883-2218295.png'
          height='40%' width='90%'> </img>
        <h3>Delivery Address</h3>
        <?php
        $sql = "SELECT * FROM cart WHERE user_id='$uid'";
        $result = $conn->query($sql);
        if ($result) {
          if ($result->num_rows > 0) {
            while ($rows = $result->fetch_assoc()):

              $qry = $conn->query("SELECT * FROM `users` WHERE id='$uid'");
              while ($row = $qry->fetch_assoc()):
                ?>
                <div style="border-top:2px solid white;border-bottom:2px solid white;">
                  <h4>Name :
                    <?php echo $row['first_name']; ?>
                    <?php echo $row['last_name']; ?>
                  </h4>
                  <h4>Address :
                    <?php echo $row['address']; ?>
                  </h4>
                  <h4>Email :
                    <?php echo $row['email']; ?>
                  </h4>
                  <h4>Contact :
                    <?php echo $row['mobile']; ?>
                  </h4>
                </div>
                <form action="" method="POST">
                  <input type="hidden" id="amount" name="amount" value='<?php echo $total_sum; ?>'>
                  <input type="hidden" id="cust_id" name="cust_id" value='<?php echo $row['id']; ?>'>
                  <input type="hidden" id="cust_name" name="cust_name" value='<?php echo $row['first_name']; ?>'>
                  <input type="hidden" id="email" name="email" value='<?php echo $row['email']; ?>'>
                  <input type="hidden" id="address" name="address" value='<?php echo $row['address']; ?>'>
                  <input type="hidden" id="product_id" name="product_id" value='<?php echo $rows['product_id']; ?>'>
                  <input type="hidden" id="p_name" name="p_name" value='<?php echo $rows['p_name']; ?>'>
                  <input type="hidden" id="p_price" name="p_price" value='<?php echo $rows['p_price']; ?>'>
                  <input type="hidden" id="qty" name="qty" value='<?php echo $rows['qty']; ?>'>
                  <input type="hidden" id="img_path" name="img_path" value='<?php echo $rows['img_path']; ?>'>
                  <input type="hidden" id="mobile" name="mobile" value='<?php echo $row['mobile']; endwhile; endwhile;
          }
        } ?>'>
          <button class='pay-btn' type='button' id="rzp-button1">Checkout</button>
        </form>
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        <script type="text/javascript">
          $(document).ready(function () {
            $('#rzp-button1').on('click', function (e) {
              e.preventDefault();
              var pay_id = '';
              //get the input from the form
              var cust_id = $("#cust_id").val();
              var name = $("#cust_name").val();
              var amount = $("#amount").val();
              var email = $("#email").val();
              var mobile = $("#mobile").val();
              var address = $("#address").val();
              var product_id = $("#product_id").val();
              var p_name = $("#p_name").val();
              var p_price = $("#p_price").val();
              var qty = $("#qty").val();
              var img_path = $("#img_path").val();
              var actual_amount = amount * 100;

              //var actual_amount = amount;
              var options = {
                "key": "rzp_test_VxXBZ37slfyArP", //"rzp_test_g9nsCrZ66aag7L", // Enter the Key ID generated from the Dashboard
                "amount": actual_amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                "currency": "INR",
                "name": "SunTech",
                "description": 'SunTech - Solars And Inverters',
                "image": "",
                // "order_id": "order_IluGWxBm9U8zJ8", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                "handler": function (response) {
                  $.ajax({
                    url: 'process_payment.php',
                    type: 'POST',
                    data: {
                      'payment_id': response.razorpay_payment_id,
                      'cust_id': cust_id,
                      'amount': amount,
                      'name': name,
                      'email': email,
                      'mobile': mobile,
                      'address': address,
                      'product_id': product_id,
                      'p_name': p_name,
                      'p_price': p_price,
                      'qty': qty,
                      'img_path': img_path
                    },
                    success: function (data) {
                      console.log(data);
                      pay_id = response.razorpay_payment_id;
                      window.location.href = 'index.php';
                    },
                  });
                  // alert(response.razorpay_payment_id);
                  // alert(response.razorpay_order_id);
                  // alert(response.razorpay_signature);
                },

              };
              var rzp1 = new Razorpay(options);
              rzp1.on('payment.failed', function (response) {
                alert(response.error.code);
                alert(response.error.description);
                alert(response.error.source);
                alert(response.error.step);
                alert(response.error.reason);
                alert(response.error.metadata.order_id);
                alert(response.error.metadata.payment_id);
              });
              document.getElementById('rzp-button1').onclick = function (e) {
                rzp1.open();
                e.preventDefault();
              }
            });
          });
        </script>
      </div>

    </div>
  </div>
</div>