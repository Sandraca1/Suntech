<?php
session_start();
if (!isset($_SESSION['aid'])) {
     header("Location: login.php");
     exit();
}
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'abidf';
$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['status']))
{
    $status=$_POST['status'];
    $orderid=$_POST['order_id'];
    $sql1="UPDATE `orders` SET `order_status`='$status' WHERE `order_id`='$orderid'";
    $result1 = $conn->query($sql1); 
    echo "<script>window.location.href='orders.php'</script>";
}
?>