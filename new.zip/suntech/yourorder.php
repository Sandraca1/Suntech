<?php
session_start();
include ('./admin/db_connect.php');
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Orders</title>
</head>

<body style="background-color:#BFE6FB;padding:2% 3%;">
    <div style="background-color:#FFFFFF;border-radius:14px;padding:2% 3%;">
        <?php
        $uid = $_SESSION['id'];
        $name = $_SESSION['first_name'];
        
        $sql = "SELECT * FROM orders WHERE cust_id=$uid";
        // $sqlone = "SELECT SUM(total) as total_sum FROM cart WHERE user_id='$uid'";
        $result = $conn->query($sql);
        // $sum = $conn->query($sqlone);
        if ($result) {
            while ($row = $result->fetch_assoc()):
                ?>
                <div style="border-bottom:solid 4px #F5F5F5;">
                    <h3>Order ID :
                        <?php echo $row['order_id']; ?>
                    </h3>
                    <h3>Place On :
                        <?php echo $row['order_date']; ?>
                    </h3>
                </div>

                <div style="display:flex;justify-content:space-between;align-items:center;width:100%;">
                    <div style="text-align:left;margin:0 auto;width:50%">
                        <h1>
                            <?php echo $row['p_name']; ?>
                        </h1>
                        <h3>Qty:
                            <?php echo $row['qty']; ?> item
                        </h3>
                        <h1>₹
                            <?php echo $row['p_price']; ?>
                        </h1>
                    </div>
                    <div style="margin:0 auto;width:50%;display:flex;justify-content:center;align-items:center;">
                        <img style="border:solid 1px;" src="./assets/img/<?php echo $row['img_path']?>" width='40%'
                            alt="product-img">
                    </div>
                </div>


                <!-- <div style="display:flex;justify-content:space-between;align-items:center;width:100%;">
        <div style="text-align:left;margin:0 auto;width:50%">
            <h1>Headphones Bose 35 II</h1>
            <h3>Qt: 1 item</h3>
            <h1>$ 299 via (COD)</h1>
        </div>
        <div style="margin:0 auto;width:50%;display:flex;justify-content:center;align-items:center;">
            <img src="./assets/img/V-Guard_Win-Hot_Series_200_LPD_Solar_Water_Heater.jpeg" width='30%' alt="product-img">
        </div>
    </div> -->

                <div>
                    <div style="width:50%;display:flex;">
                        <span
                            style="<?php if ($row['order_status'] == 'pending') {
                                echo 'background-color:grey;';
                            } else {
                                echo 'background-color:#1266F1;';
                            } ?>padding:2%;border-radius:100%;color:#FFFFFF;font-size:1.2rem;">1</span><span
                            style="font-weight:800;<?php if ($row['order_status'] == 'pending') {
                                echo 'color:black;';
                            } else {
                                echo 'color:#1266F1;';
                            } ?>">_____________________________</span>
                        <span
                            style="<?php if ($row['order_status'] != 'pending') {
                                echo 'background-color:#1266F1;';
                            } else {
                                echo 'background-color:grey;';
                            } ?>padding:2%;border-radius:100%;color:#FFFFFF;font-size:1.2rem;">2</span><span
                            style="font-weight:800;<?php if ($row['order_status'] == 'delivered') {
                                echo 'color:#1266F1;';
                            } else {
                                echo 'color:black';
                            } ?>">_____________________________</span>
                        <span
                            style="<?php if ($row['order_status'] == 'delivered') {
                                echo 'background-color:#1266F1;';
                            } else {
                                echo 'background-color:grey;';
                            } ?>padding:2%;border-radius:100%;color:#FFFFFF;font-size:1.2rem;">3</span>
                    </div>
                    <div style="margin-top:2%;display:flex;justify-content:space-between;width:50%">
                        <span>Pending</span>
                        <span>On the way</span>
                        <span>Deliveried</span>
                    </div>
                </div>
            <?php endwhile;
        } ?>
    </div>
</body>

</html>