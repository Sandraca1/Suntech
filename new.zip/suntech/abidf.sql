-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2024 at 10:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abidf`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(2) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', 'Admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cid` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_id` int(30) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `p_price` float NOT NULL,
  `qty` int(30) NOT NULL,
  `img_path` varchar(300) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cid`, `user_id`, `product_id`, `p_name`, `p_price`, `qty`, `img_path`, `total`) VALUES
(54, 3, 9, 'Exide 150 Ah Inva Red 500 Plus', 4524, 1, 'Exide_150_Ah_Inva_Red_500_Plus_Inerter_Battery.jpeg', 4524),
(58, 9, 3, 'High Efficiency Monocrystallin', 1500, 2, 'High_Efficiency_Monocrystalline_Silicone_Solar_Panel.jpeg', 3000),
(59, 11, 7, 'V-Guard Win-Hot Series 200 LPD', 5422, 2, 'V-Guard_Win-Hot_Series_200_LPD_Solar_Water_Heater.jpeg', 10844);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `cust_id` int(11) DEFAULT NULL,
  `cust_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `p_name` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `order_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `img_path` text NOT NULL,
  `qty` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `name`, `description`, `price`, `img_path`, `qty`) VALUES
(3, 'High Efficiency Monocrystalline Silicone Solar Panel', 'Lorem ipsum dolor set amet', 1500, 'High_Efficiency_Monocrystalline_Silicone_Solar_Panel.jpeg', '1498'),
(5, 'Havells Solar Panel', 'havells solar panel', 4352, 'Havells_Solar_Panel.jpeg', '195'),
(6, 'Vguard Solar Water Heater', 'The Vguard solar water heaters come with a high-efficiency evacuated tube collector, which absorbs heat from the sun and transfers it to the water. ', 4322, 'Vguard_Solar_Water_Heater.jpeg', '496'),
(7, 'V-Guard Win-Hot Series 200 LPD Solar Water Heater', 'The V-Guard Win-Hot Series 200 LPD Solar Water Heater comes with a high-efficiency evacuated tube collector that absorbs heat from the sun and transfers it to the water. ', 5422, 'V-Guard_Win-Hot_Series_200_LPD_Solar_Water_Heater.jpeg', '397'),
(8, 'Solar Geyser', 'A solar geyser is a type of water heating system that uses the power of the sun to heat water.', 1770, 'Solar_Geyser.jpeg', '4997'),
(9, 'Exide 150 Ah Inva Red 500 Plus Inerter Battery', 'The Exide 150 Ahcapacity of 150 Ah, making it an ideal solution for homes or businesses with high power requirements.', 4524, 'Exide_150_Ah_Inva_Red_500_Plus_Inerter_Battery.jpeg', '2979');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'SunTecH', 'admin@admin.com', '+639079373999', '1668911820_background.jpg', 'Welcome to our inverter and solar website! We are a team of passionate professionals dedicated to providing sustainable energy solutions for homes and businesses alike.\n\nOur journey began with a simple idea: to create a cleaner, more sustainable world by harnessing the power of the sun. As we delved deeper into the world of solar energy, we realized that in order to truly make a difference, we needed to offer a complete solution that not only generated energy, but also stored and managed it efficiently. This led us to the world of inverters and battery storage systems, where we have since become experts in the field.\n\nAt our core, we are committed to making solar energy accessible to everyone. We believe that everyone should have the opportunity to benefit from the cost savings and environmental benefits of renewable energy, regardless of their location or budget. That\'s why we offer a wide range of products and services, from simple off-grid systems for remote locations, to complex grid-tied systems for commercial applications.\n\nOur team is made up of experienced professionals who are passionate about what they do. We have engineers, designers, installers, and customer service representatives who all work together to ensure that our clients receive the best possible service and support. We are committed to staying up-to-date with the latest technology and trends in the industry, so that we can continue to offer the most advanced and effective solutions to our clients.\n\nWe understand that investing in a solar energy system can be a significant decision, which is why we take the time to understand our clients\' unique needs and goals. We work closely with our clients to design and install customized solutions that meet their specific requirements, while also providing ongoing support and maintenance to ensure that their system operates at peak efficiency.\n\nThank you for considering us as your partner in the journey towards a sustainable future. We look forward to working with you to create a brighter, cleaner world for generations to come.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile`, `address`, `password`) VALUES
(1, 'Richu', 'Sony', 'sonyrichu4@gmail.com', '9947619644', 'adfadfa adfada adfadf adfadf adfadf afd', 'richusony123'),
(3, 'Simal', 'Baby', 'simal@gmail.com', '8086219644', 'adfadfadfadfa', 'simaL12345'),
(9, 'SHIKHA', 'P', 'shikha@gmail.com', '9645813845', 'TRVM', 'Shikha123'),
(11, 'SANDRA', 'C A', 'sa@gmail.com', '7777777777', 'knr', 'Sandra123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
