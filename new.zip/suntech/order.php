<?php
session_start();
if (!isset($_SESSION['id'])) {
     header("Location: login.php");
     exit();
}
$name = $_SESSION['first_name'];
?> 
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Your Cart</title>
     <link rel="stylesheet" href="./css/styles.css">
     <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/891/891462.png" type="image/x-icon">
</head>
<body>
    <div style="padding:15px;margin:5% 0;font-size:20px;text-align:center;">Your order has been placed.</div>
   <?php echo "<div style='width:100%' class='empty-cart'>
			   						<div style='width:100%;margin:0 auto;'>
                                     <img style='display:flex;justify-content:center;margin:0 auto;width:20%;' src='./assets/img/order.png' alt=''/>
                                     <h1 style='text-align:center'>" . $name . ", Thank you for ordering!</h1>
									 </div>
                               </div>" ?>
    <div style="text-align:center;"><a href='/suntech/index.php?page=home'>Home</a></div>
</body>
</html>
