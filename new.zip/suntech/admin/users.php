<?php
session_start();
if (!isset($_SESSION['aid'])) {
     header("Location: login.php");
     exit();
}
$i=0;
?>
<?php include("navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SunTech - Products</title>
    <link rel="stylesheet" href="../css/admin.scss">
	<style>
		#customers {
		font-family: Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		width: 100%;
		}

		#customers td, #customers th {
		border: 1px solid #ddd;
		padding: 8px;
		}

		#customers tr:nth-child(even){background-color: #f2f2f2;}

		#customers tr:hover {background-color: #ddd;}

		#customers th {
		padding-top: 12px;
		padding-bottom: 12px;
		text-align: left;
		background-color: #04AA6D;
		color: white;
		}
    
#addp {
  background-color: #2ea44f;
  border-radius: 8px;
  border-style: none;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  font-weight: 500;
  height: 40px;
  line-height: 20px;
  list-style: none;
  margin: 0;
  outline: none;
  padding: 10px 16px;
  position: relative;
  text-align: center;
  text-decoration: none;
  transition: color 100ms;
  vertical-align: baseline;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

#addp:hover,
#addp:focus {
  background-color: transparent;
  border: solid #2ea44f 1px;
  color:black;
}


#updateb {
  background-color: #2962FF;
  border-radius: 8px;
  border-style: none;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  font-weight: 500;
  height: 40px;
  line-height: 20px;
  list-style: none;
  margin: 0;
  outline: none;
  padding: 10px 16px;
  position: relative;
  text-align: center;
  text-decoration: none;
  transition: color 100ms;
  vertical-align: baseline;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

#updateb:hover,
#updateb:focus {
	background-color: transparent;
  border: solid #2962FF 1px;
  color:black;
}


#deleteb {
  background-color: #EA4C89;
  border-radius: 8px;
  border-style: none;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  font-weight: 500;
  height: 40px;
  line-height: 20px;
  list-style: none;
  margin: 0;
  outline: none;
  padding: 10px 16px;
  position: relative;
  text-align: center;
  text-decoration: none;
  transition: color 100ms;
  vertical-align: baseline;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

#deleteb:hover,
#deleteb:focus {
	background-color: transparent;
  border: solid #EA4C89 1px;
  color:black;
}
	</style>
	</head>
	<body>
		<h1 style="text-align:center;margin:7% 0;font-size:3rem;">Users</h1>
    	<div style="padding:5% 20px;">
			<div style="text-align:right;margin-bottom:10px;">
			<a href="deleteuser.php"><button id="deleteb">Delete</button></a>	
			</div>
			<table id="customers">
				<tr>
					<th>Slno</th>
					<th>User ID</th>
					<th>First Name</th>
					<th>Second Name</th>
					<th>Email</th>
					<th>Moblie</th>
					<th>Address</th>
					
				</tr>
				<?php 
									include 'db_connect.php';
									$qry = $conn->query("SELECT * FROM `users` ORDER BY `users`.`first_name` ASC");
									while($row = $qry->fetch_assoc()):
									?>
				<tr>
					<td><?php echo $i=$i + 1  ?></td>
					<td><?php echo $row['id'] ?></td>
					<td><?php echo $row['first_name'] ?></td>
					<td><?php echo $row['last_name'] ?></td>
					<td><?php echo $row['email'] ?></td>
					<td><?php echo $row['mobile'] ?></td>
					<td><?php echo $row['address'] ?></td>
					
				</tr>
				<?php endwhile; ?>
			</table>
    	</div>
		<?php include("footer.php"); ?>
	</body>
</html>