<?php
session_start();
if (!isset($_SESSION['aid'])) {
    header("Location: login.php");
    exit();
}
?>
<?php include("navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Orders</title>
    <style>
        /* Additional CSS to target the canvas element */
        #chart-container {
            width: 100%;
            height: 80vh; /* Adjust as needed */
        }
    </style>
</head>

<body>
    <section style="padding:2rem 3rem;">
        <h1 style="margin-bottom:1rem; font-weight: bolder; font-size: 2rem">Product Orders</h1>
        <div id="chart-container">
            <canvas id="myChart"></canvas>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        <?php
        include 'db_connect.php';
        $labels = [];
        $data = [];
        $qry = $conn->query("SELECT p_name, COUNT(*) as total_orders FROM orders GROUP BY p_name");
        while ($row = $qry->fetch_assoc()):
            $labels[] = $row['p_name'];
            $data[] = $row['total_orders'];
        endwhile;
        ?>

        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Order Count by Product',
                    data: <?php echo json_encode($data); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });

        // Adjust chart size dynamically based on available space
        function adjustChartSize() {
            var container = document.getElementById('chart-container');
            var chart = document.getElementById('myChart');
            chart.width = container.offsetWidth;
            chart.height = container.offsetHeight;
        }

        // Call the adjustChartSize function initially and on window resize
        adjustChartSize();
        window.addEventListener('resize', adjustChartSize);
    </script>
</body>

</html>
