<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="icon" type="image/x-icon" href="./assets/img/nav-logo-1.png">
  <title>SunTecH</title>
 	

<?php include('./header.php'); ?>
<?php include('./db_connect.php'); ?>
<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $input_email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
     $input_password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

	 if($input_email == '' && $input_password == ''){
		echo "<script>alert('Please enter all fields.');</script>";
	}
	else if($input_email == ''){
		echo "<script>alert('Username cannot be empty.');</script>";
	}
	else if($input_password == ''){
		echo "<script>alert('Password cannot be empty.');</script>";
	}
	
      
     else{

     try {
          
          $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
          $stmt->bind_param("s", $input_email);
          $stmt->execute();
          $result = $stmt->get_result();

          if ($result->num_rows == 1) {
               $row = $result->fetch_assoc();
               $db_uid = $row['id'];
               $db_first_name = $row['name'];
               $db_email = $row['email'];
               $db_password = $row['password'];

               // Verify input password
               if ($input_password == $db_password && $input_email == $db_email) {
                    $_SESSION['aid'] = $db_uid;
                    $_SESSION['name'] = $db_first_name;
                    $_SESSION['email'] = $db_email;
                    header('Location: index.php');
                    exit();
               } else {
                    echo "<script>alert('Incorrect Email  or Password.');</script>";
                    echo "<script>window.location.href='login.php'</script>";
               }
          } else {
               echo "<script>alert('User not found.');</script>";
               echo "<script>window.location.href='login.php'</script>";
          }

          $conn->close();
     } catch (Exception $e) {
          $error_message = $e->getMessage();
     }
     }
}
?>

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
	}
	#login-left{
		position: absolute;
		left:0;
		width:100%;
		height: 100%;
		display: flex;
		/* background-image: url("../assets/img/admin-login.jpg"); */
		background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-size: cover;
	}
	#login-right .card{
		margin: auto
	}
	
</style>

<body>


  <main id="main" class=" bg-dark">
  		<div id="login-left">
  			<div class="logo">
  				<img style='margin:30%;' src="../assets/img/admin-login.jpg" alt="">
  			</div>
  		</div>
  		<div id="login-right">
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form id="login-form" method="POST" >
  						<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="email" id="username" name="email" class="form-control">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>	
</html>