<?php
session_start();
if (isset($_SESSION['user_id'])) {
     header('Location: index.php');
     exit();
}

$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'abidf';
$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

$firstname = isset($_POST['first_name']) ? $_POST['first_name'] : '';
$lastname = isset($_POST['last_name']) ? $_POST['last_name'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';


if(!$firstname && !$lastname && !$email && !$mobile && !$address && !$password){
     echo "<script>alert('Fill all the details.');</script>";
}
else if($firstname == ''){
     echo "<script>alert('firstname cannot be empty.');</script>";
}
else if($lastname == ''){
     echo "<script>alert('lastname cannot be empty.');</script>";
}
else if($email == ''){
     echo "<script>alert('email cannot be empty.');</script>";
}
else if($mobile == ''){
     echo "<script>alert('mobile cannot be empty.');</script>";
}
else if($address == ''){
     echo "<script>alert('address cannot be empty.');</script>";
}
else if($password == ''){
     echo "<script>alert('Password cannot be empty.');</script>";
}
else{
     echo "<script>console.log('all fields are ok');</script>";

     if (!empty($_POST)) {
          if (!preg_match('/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
          echo "<script>alert('Invalid Email');</script>";
          }
          else if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/', $password)) {
          echo "<script>alert('password must be at least 8 characters &  one  lowercase  and one uppercase letter and one number and No special characters.');</script>";
          }

          else if (!preg_match("/^([0-9]{10,10})$/", $mobile)) {
          echo "<script>alert('Enter a valid Mobile Number');</script>";
          }
          
          else{
      
               // check if email already exists in database
               $email_exists_query = "SELECT * FROM users WHERE email = '$email'";
               $result = mysqli_query($conn, $email_exists_query);
               if (mysqli_num_rows($result) > 0) {
                    echo "<script>alert('Email already exists');</script>";
               } else {
                    // insert user data into database
                    $sql = "INSERT INTO users (first_name, last_name, email, mobile, address, password) VALUES ('$firstname', '$lastname', '$email', '$mobile', '$address', '$password')";
                    if (mysqli_query($conn, $sql)) {
                         echo "<script>alert('account created');
                         window.location.href='login.php';</script>";
                    } else {
                         echo "<script>alert('Account creation failed!');</script>";
                    }
               }
          }
     }
}
mysqli_close($conn);
?>
<div style='background-color:#c4c1e0;width:100%; height:100%;padding:5% 0;' class="container-fluid">
<h1 style='text-align:center;'>Sign Up</h1>
	<form method="POST" id="login-frm" style='margin:0 auto;width:25%;border-radius:10px;background-color:#7c73e6;padding:10px 15px;'>
		<div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >FirstName</label>
			<input type="text" style="font-size:16px;padding: 2px;width:100%;" name="first_name" class="form-control" placeholder="Enter your First Name" >
		</div>

		<div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >LastName</label>
			<input type="text" style="font-size:16px;padding: 2px;width:100%;" name="last_name" class="form-control" placeholder="Enter your Second Name" >
		</div>

		<div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Email</label>
			<input style="font-size:16px;padding: 2px;width:100%;" type="email" name="email" id="passwd" placeholder="Enter your email" class="form-control">
		</div>

          <div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Mobile</label>
			<input type="text" style="font-size:16px;padding: 2px;width:100%;" name="mobile" class="form-control" placeholder="Enter your Mobile" >
		</div>

          <div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Address</label>
			<textarea name="address" class="form-control" id="address" rows="3" cols="39"></textarea>
		</div>

          <div class="form-group" style="margin: 10px auto;">
			<label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Password</label>
			<input type="password" style="font-size:16px;padding: 2px;width:100%;" name="password" class="form-control" placeholder="Enter your Password" >
		</div>
          
          <div style="display:flex;justify-content:center;">
               <input type="submit" style="margin:0 auto;font-size:20px;cursor:pointer;" value="Sign Up"  class="button btn btn-info btn-sm" />
          </div>    
	</form>
</div>
