<?php
session_start();
if (!isset($_SESSION['aid'])) {
    header("Location: login.php");
    exit();
}
$i = 0;
?>
<?php include ("navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report</title>
    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }


        #addp {
            background-color: #2ea44f;
            border-radius: 8px;
            border-style: none;
            box-sizing: border-box;
            color: #FFFFFF;
            cursor: pointer;
            display: inline-block;
            font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            font-weight: 500;
            height: 40px;
            line-height: 20px;
            list-style: none;
            margin: 0;
            outline: none;
            padding: 10px 16px;
            position: relative;
            text-align: center;
            text-decoration: none;
            transition: color 100ms;
            vertical-align: baseline;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
        }

        #addp:hover,
        #addp:focus {
            background-color: transparent;
            border: solid #2ea44f 1px;
            color: black;
        }


        #updateb {
            background-color: #2962FF;
            border-radius: 8px;
            border-style: none;
            box-sizing: border-box;
            color: #FFFFFF;
            cursor: pointer;
            display: inline-block;
            font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            font-weight: 500;
            height: 40px;
            line-height: 20px;
            list-style: none;
            margin: 0;
            outline: none;
            padding: 10px 16px;
            position: relative;
            text-align: center;
            text-decoration: none;
            transition: color 100ms;
            vertical-align: baseline;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
        }

        #updateb:hover,
        #updateb:focus {
            background-color: transparent;
            border: solid #2962FF 1px;
            color: black;
        }


        #deleteb {
            background-color: #EA4C89;
            border-radius: 8px;
            border-style: none;
            box-sizing: border-box;
            color: #FFFFFF;
            cursor: pointer;
            display: inline-block;
            font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            font-weight: 500;
            height: 40px;
            line-height: 20px;
            list-style: none;
            margin: 0;
            outline: none;
            padding: 10px 16px;
            position: relative;
            text-align: center;
            text-decoration: none;
            transition: color 100ms;
            vertical-align: baseline;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
        }

        #deleteb:hover,
        #deleteb:focus {
            background-color: transparent;
            border: solid #EA4C89 1px;
            color: black;
        }
    </style>
</head>

<body>
    <section style="padding:2rem 3rem;">
        <h1 style="margin-bottom:1rem; font-weight: bolder; font-size: 2rem">Report</h1>
        <div style="margin: 1rem 0;  width: 300px;">
            <form style="display: flex; flex-direction: column; justify-content:center;" action="handle_report_filter.php" method="POST">
                <label style="font-weight: bold;" for="startDate">Start Date</label>
                <input style="padding: 5px 2px; border-radius:4px;" type="date" name="startDate" id="startDate">
                <label style="margin-top: 1rem; font-weight: bold;" for="endDate">End Date</label>
                <input style="padding: 5px 2px; border-radius:4px;" type="date" name="endDate" id="endDate">
                <button type="submit" name="applyFilter"
                    style="margin-top:1rem; width: 50%; border:none; padding:8px 0; background-color:blue; color:white; border-radius:4px;">Apply</button>
            </form>

        </div>
        <div style="margin-top: 2rem;">
            <table id="customers">
                <tr>
                    <th>Slno</th>
                    <th>Order ID</th>
                    <th>Customer ID</th>
                    <th>Customer Name</th>
                    <th>Address</th>
                    <th>Amount</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Date</th>
                </tr>
                <?php
                include 'db_connect.php';
                $qry = $conn->query("SELECT * FROM orders"); //WHERE order_status='delivered'
                while ($row = $qry->fetch_assoc()):
                    ?>
                    <tr>
                        <td>
                            <?php echo $i = $i + 1 ?>
                        </td>
                        <td>
                            <?php echo $row['order_id'] ?>
                        </td>
                        <td>
                            <?php echo $row['cust_id'] ?>
                        </td>
                        <td>
                            <?php echo $row['cust_name'] ?>
                        </td>
                        <td>
                            <?php echo substr($row['address'], 0, 50) ?>
                        </td>
                        <td>
                            <?php echo $row['amount'] ?>
                        </td>
                        <td>
                            <?php echo $row['p_name'] ?>
                        </td>
                        <td>
                            <?php echo $row['qty'] ?>
                        </td>
                        <td>
                            <?php echo $row['order_date'] ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </section>
</body>

</html>