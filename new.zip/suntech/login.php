<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $input_email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
     $input_password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

     if($input_email == ''){
          echo "<script>alert('email cannot be empty.');</script>";
     }
     else if($input_password == ''){
          echo "<script>alert('Password cannot be empty.');</script>";
     }
      
     else{


     $host = 'localhost';
     $username = 'root';
     $password = '';
     $dbname = 'abidf';
     $error_message = " ";

     try {
          $conn = new mysqli($host, $username, $password, $dbname);
          if ($conn->connect_error) {
               throw new Exception("Connection failed: " . $conn->connect_error);
          }

          $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
          $stmt->bind_param("s", $input_email);
          $stmt->execute();
          $result = $stmt->get_result();

          if ($result->num_rows == 1) {
               $row = $result->fetch_assoc();
               $db_uid = $row['id'];
               $db_first_name = $row['first_name'];

               $db_email = $row['email'];
               $db_password = $row['password'];

               // Verify input password
               if ($input_password == $db_password && $input_email == $db_email) {
                    $_SESSION['id'] = $db_uid;
                    $_SESSION['first_name'] = $db_first_name;
                    $_SESSION['email'] = $db_email;
                    
                    header('Location: index.php');
                    exit();
               } else {
                    echo "<script>alert('Incorrect Email  or Password.');</script>";
                    // echo "<script>window.location.href='login.php'</script>";
               }
          } else {
               echo "<script>alert('User not found.');</script>";
               echo "<script>window.location.href='login.php'</script>";
          }

          $conn->close();
     } catch (Exception $e) {
          $error_message = $e->getMessage();
     }
     }
}
?>

<div style='background: linear-gradient(to bottom, #000080, white); width: 100%; height: 100%; padding: 10% 0; position: relative;' class="container-fluid">
    <div style="position: absolute; top: 0; left: 20px; bottom: 0; display: flex; align-items: center;">
        <img src="so1.png" alt="icon" style="width: 100px; height: 100px; opacity: 0.8;">
    </div>
    <h1 style='text-align:center;color:white;'>User Login</h1>
    <form method="POST" id="login-frm" style='margin:0 auto;width:25%;border-radius:10px;background-color:#000080;padding:10px 15px;'>
        <div class="form-group" style="margin: 10px auto;">
            <label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Email</label>
            <input type="email" style="font-size:16px;padding: 2px;width:100%;" name="email" class="form-control" placeholder="Enter your email" >
        </div>
        <div class="form-group" style="margin: 10px auto;">
            <label for="" style="font-size:20px;display:block;color:white;" class="control-label" >Password</label>
            <input style="font-size:16px;padding: 2px;width:100%;" type="password" name="password" id="passwd" placeholder="Enter your password" class="form-control"><br>
            <h3 style="margin-top:10px;"><a href="./signup.php" style="font-size:16px;text-decoration:none;color:white;" id="new_account">Create account</a></h3>
        </div>
        <div style="display:flex;justify-content:center;">
            <input type="submit" style="margin:0 auto;font-size:20px;cursor:pointer;" value="Login" onclick="handleLogin();" class="button btn btn-info btn-sm" />
        </div>    
    </form>
    <div style="position: absolute; top: 0; right: 20px; bottom: 0; display: flex; align-items: center;">
        <img src="so1.png" alt="icon" style="width: 100px; height: 100px; opacity: 0.8;">
    </div>
</div>
<style>
    body {
        overflow: hidden; /* Prevent scrolling */
    }

    #uni_modal .modal-footer{
        display:none;
    }
</style>
