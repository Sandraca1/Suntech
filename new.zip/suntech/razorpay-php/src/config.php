<?php

// Define your Razorpay API keys here
$razorpay_api_key = 'rzp_test_QhCniYFsfLovui ';
$razorpay_api_secret = 'TocxVmQjroAE8eUC8Q0SkbmX';
