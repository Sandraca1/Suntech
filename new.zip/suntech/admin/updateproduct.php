<?php
session_start();
if (!isset($_SESSION['aid'])) {
     header("Location: login.php");
     exit();
}
 include("navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update products</title>
    <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}
        /* Style inputs, select elements and textareas */
input[type=text], select, textarea{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  resize: vertical;
}

/* Style the label to display next to the inputs */
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

/* Style the submit button */
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

/* Style the container */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
    </style>
</head>
<?php
// echo $updateid;
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'abidf';
$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

// insert user data into database
$updateid = $_SESSION['updateid'];
$sql = "SELECT * FROM  product_list WHERE id='$updateid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {

?>
<body>
    <h1 style="text-align:center;margin-top:3%;">Update Products</h1>
    <div style="padding:5px 20px;margin:5% 0;">
      
        <div class="container">
            <form method="POST">
    <div class="row">
      <div class="col-25">
        <label for="fname">Product ID</label>
      </div>
      <div class="col-75">
        <input type="text" readonly value="<?php echo $row['id'] ?>" id="fname" name="pid" placeholder="Product Name">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Product Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" value="<?php echo $row['name'] ?>" name="pname" placeholder="Product Name">
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="subject">Description</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="desc" value="<?php echo $row['description'] ?>" placeholder="Write Description.." style="height:200px"><?php echo $row['description'] ?></textarea>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="lname">price</label>
      </div>
      <div class="col-75">
        <input type="text" id="lname" value="<?php echo $row['price'] ?>" name="price" placeholder="Price of the product">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Image</label>
      </div>
      <div class="col-75">
        <img src="../assets/img/<?php echo $row['img_path']; ?>" width="15%"/>
        <input type="hidden" name="image" value="<?php echo $row['img_path']; ?>">
      <input type="file" id="lname" value="<?php  echo $row['img_path'] ?>" name="img" placeholder="Price of the product"><?php echo $row['img_path'] ?>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Quantity</label>
      </div>
      <div class="col-75">
      <input type="text" id="lname" value="<?php echo $row['qty'] ?>" name="qty" placeholder="Quantity of the product">
      </div>
    </div>

    <div class="row"style="text-align:center;" >
      <input type="submit" value="Submit" name="submit"/>
    </div>
  </form>
</div>
  
</div>
<?php
    }
}
if(isset($_POST['submit'])){
    $id=$_POST['pid'];
    $pname=$_POST['pname'];
    $desc=$_POST['desc'];
    $price=$_POST['price'];
    $qty=$_POST['qty'];
    $img_path= $_POST['img'];
    $sqlone = "UPDATE product_list SET id='$id',name='$pname',description='$desc',price='$price',img_path='$img_path',qty='$qty' WHERE id=$updateid";
    $result = $conn->query($sqlone);
    if($result){
      
     echo "<script>alert('Successfull!');
     window.location.href='product.php';
     </script>";
    }else{
        echo "<script>alert('Fail!');
        window.location.href='product.php';
        </script>";
    }
    
}
?>
</body>
<?php include("footer.php"); ?>
</html>