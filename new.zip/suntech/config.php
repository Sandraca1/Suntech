<?php
$keyId='rzp_test_VxXBZ37slfyArP';
$keySecret='CcMG1o05q8Xclw0WRQfU2lJW';
$displayCurrency='INR';


error_reporting(E_ALL);
ini_set('display_errors',1);