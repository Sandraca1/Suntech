<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abidf";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
$p_id = $_POST['del_pid'];
$qty = $_POST['item_qty'];

$sql = "DELETE FROM cart WHERE product_id='$p_id'";
$result = $conn->query($sql);
$updateQty = "UPDATE product_list  SET qty = qty +'$qty' WHERE id = '$p_id'";
if ($result) {
     $conn->query($updateQty);
     echo "hgjgkhjg";
     echo "<script>alert('item has been removed from cart.');</script>";
     // header('Location: index.php?page=cart_list');
     echo "<script>window.location.href='index.php?page=cart_list'</script>";
} else {
     echo "Removing item failed!";
}

$conn->close();
